package com.menu;

import java.io.IOException;
import javafx.fxml.FXML;

public class Sample extends Menu {

    @FXML private void toMenu() throws IOException {super.toMainMenu();}
}
