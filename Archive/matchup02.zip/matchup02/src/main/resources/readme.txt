Types:
M = melee
R = ranged
E = explosive
F = fire
W = water
L = electric
G = magic
C = mechanical
A = aerial
I = ice
S = star
V = evil

day should be replaced with fire and night replaced with water
replace IP with star

league file format 
1: int of fighters per team

IDs from freshman era +900
...
*team name
one fighter per line, follow guide
name pos types base strType strVal wkType wkVal

entry codes
1+: menu choice
0: exit program
-1: standard exit
-2+: exit by error