package com.javafx;

import java.io.IOException;
import javafx.fxml.FXML;

public class Sample extends MenuHandler {

    @FXML private void toMenu() throws IOException {super.toMainMenu();}
}
